obs = obslua

function script_description()
    return "Stops and re-enables replay buffer when a replay is saved."
end

function script_load(settings)
    obs.obs_frontend_add_event_callback(on_event)
end

function on_event(event)
    if event == obs.OBS_FRONTEND_EVENT_REPLAY_BUFFER_SAVED then
        toggle_replay_buffer()
    end
end

function toggle_replay_buffer()
    local replay_buffer_active = obs.obs_frontend_replay_buffer_active()
   
    if replay_buffer_active then
        obs.obs_frontend_replay_buffer_stop()
        obs.timer_add(start_replay_buffer, 2000)  -- Re-enable after 2 second
    end
end

function start_replay_buffer()
    obs.timer_remove(start_replay_buffer)
    obs.obs_frontend_replay_buffer_start()
end